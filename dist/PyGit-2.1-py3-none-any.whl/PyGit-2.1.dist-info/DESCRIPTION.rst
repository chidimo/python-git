PyGit
============

Automate the boring git stuff with python

`Documentation on readthedocs <http://pygit.readthedocs.io/en/latest/>`_

Motivation
-----------
Whenever I wanted to see the status of all my git repos I have to fire up the 
**git-cmd.exe** shell on windows, navigate to each folder and then do a git status. 
I have to do this both at home and at work.

But I got quickly tired of it. So I decided to make this tool to give me a quick 
report so I can see what is ahead and what's behind and what's ahead at a glance.


Requirements
--------------

`Git <https://git-scm.com/download/win>`_

On a computer without admin access? Grab the portable version; unzip and place it somewhere on your disk.


Installation
--------------

>From Github ::

    pip install https://bitbucket.org/parousiaic/pygit/get/master2.0.zip

Setup
---------
Upon successful installation do ::

   import pygit

A successful import returns nothing on the screen.

Pygit assumes that you have a single master directory inside which you put all your git repositories. 
It works by creating a number of files from which it reads information about your repositories and git executable.
To set the necessary files run ::

   pygit.set_all()

You will be prompted to choose two folders.

1. the folder housing all your git repositories.

2. the root folder of your git installation.

In case things change (perhaps you moved folders around) and you want to reset your folders, 
just run the `set_all()` command again


After this step you're all set to start using `pygit <https://bitbucket.org/parousiaic/pygit/src>`_

To see all available repositories run ::

   pygit.repo_list()

This command shows a list of all available repositories in the format ::

   repository_id: repository_name: repository_directory_path

To load a particular repository use ::

   pygit.load(repo_id)

where **repo_id** is a string-valued id assigned to that particular repo. The first value in the `repo_list` command's output.


The **load\(\)** command returns a `Commands` object for that repo, which provides a gateway for issuing git commands on the repository

Operations that can be performed on `Commands` object are shown below. ::

   Commands().fetch() # perform fetch.

   Commands().status() # see status

   Commands().add_all() # stage all changes for commit

   Commands().commit(message='minor changes') # commit changes. Press enter to accept default message

   Commands().push() # perform push action

   Commands().pull() # perform pull request

   Commands().add_commit() # add and commit at once



Batch Operations
------------------

Pygit provides some functions for performing batch operations on your repositories. ::

   pygit.load_set(*args)

loads a set of repositories. You could decide to only load only 2 of 10 repositories. Perhaps you need to perform similar actions
on those two alone. As an example ::

   pygit.load_set("2", "5")

returns a  `generator`  of  `Commands`  objects for repositories 2 and 5. Afterwards you can use a  :py:func:`for`  loop to iterate over the repos
like below ::

   for each in pygit.load_set("2", "5"):
      each.add_commit()


::

   pygit.status_all()


performs a **status** command on all your repositories. The result is written to a text file. The text file opens automatically.
The name of the file shows the date and time of the status request. All batch status request is written to its a separate file.
Call it a snapshot of your repo status if you will
Those items which are out of sync with their remote counterpart (by being ahead or being behind) are also highlighted as needing attention. ::

   pygit.pull_all()


performs a **pull** request on all your repositories at once. Its  `return`  value is  None. ::

   pygit.push_all()


performs a **push** action on all your repositories at once. Its  `return` value is  None. ::

   pygit.load_all()


returns a  `generator`  of  `Commands`  object for every repository.


API
=====
.. automodule :: pygit.api
   :members:

Commands
=============

.. automodule :: pygit.commands
   :members:

Utility Functions
=======================

.. automodule :: pygit.utils
   :members:

To do
======

Add **git-bash.exe**

Implement Commands.branch()

Find out why importing pygit for first time gives an PermissionError
Write tests

Run test after importation to make sure every other thing works fine.

Define an update function that updates the repo dictionaries for the case when a new repo is added but the overall directory structure remains unchanged.


